<?php
    session_start();

    $email = "";
    $errors = array();
    $db = new mysqli('localhost', 'root','','customer');
if (isset($_POST['login_user'])) {
    $username = mysqli_real_escape_string($db, $_POST['username']);
    $password = mysqli_real_escape_string($db, $_POST['password']);
    
    $query = "SELECT * FROM account WHERE username='$username' AND password='$password'";
    $results = mysqli_query($db, $query);
    if (mysqli_num_rows($results) == 1) {
      header('location: Unique_user_page.html');
    }else {
      header('location: Log in Page.php');
    }
  }
?>