<?php if (count($errors) > 0 ):?>
	<div class = "error">
		<?php foreach ($errors as $error ): ?>
			 <p><?php echo $error ?></p>
	    <?php endforeach ?>
	</div>
<?php endif ?>
		if(empty($firstname)){
    		array_push($errors, "First Name is required");

    	}
    	if(empty($lastname)){
    		array_push($errors, "Last Name is required");
    	}
    	if(empty($email)){
    		array_push($errors, "Email is required");
    	}
    	if(empty($DOB)){
    		array_push($errors, "Birthday is required");
    	}
    	if(empty($phoneno)){
    		array_push($errors, "Phone Number is required");
    	}
    	if(empty($Gender)){
    		array_push($errors, "Gender is required");
    	}
    	if(empty($password)){
    		array_push($errors, "Password is required");
    	}
    	if ($password != $confirmpassword){
    		array_push($errors, "Password must match each other");
    	}
    	
    	