<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

HTML files in the HTML-WebsiteCode ending in '(HTML)' are pages that require PHP to be functional.

In order to allow you, the marker, to successfully load these pages without the aid of a functional server,
the PHP connecting code has been removed from these pages, allowing them to be properly loaded in your browser
of choice.The PHP for these pages are still featured in this folder and are, as expected, available for Code Review.

The Pages that fit this description are as follows:
> Log In Page
> Sign Up (Create Account) page
> Book Lesson Page

<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>

