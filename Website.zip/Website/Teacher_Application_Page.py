from urllib import urlopen
# Import the standard SQLite functions just in case they're needed.

#--------------------------------------------------------------------#

def Teacher_Application_Page(): #Change the name of this definition to your user story. E.g. Login_Page, Administration_Page, etc.

    #Creating MusicSchool.html file to be written to
    file_name = 'Teacher_Application_Page.html'

    #Opening created File
    Teacher_Application_Page = open(file_name, 'w+')
    
    html_code = """

    <body style="background-image:url('background.jpg')">

    </body>
    <Center>
    <form action="action_page.php" style="border:1px solid #ccc">
    <div class="container">
    <h1>Apply for a Teaching Position</h1>
    <p>Please fill in this form to Apply for a Teaching Position.</p>
    <hr>
    
    <br>
    <label for="email"><b>Email</b></label>
    <br>
    <input type="text" placeholder="Enter Email" name="email" required>
    <br>
    
    <br>
    <label for="DOB"><b>Enter Date of Birth</b></label>
    <br>
    <input type="text" placeholder="dd/mm/yyyy" name="Date Of Birth" required>
    <br>

    <br>
    <label for="Phone No."><b>Enter Contact Number</b></label>
    <br>
    <input type="text" placeholder="00 0000 0000" name="Phone Number Required" required>
    <br>

    <p>Select Gender <select name="cars"> <option value="volvo">Male</option> <option value="saab">Female</option> <option value="fiat">Other</option> </select> </p>
    
    <p>Select Position <select name="positions"> <option value="pos1">Teacher</option> <option value="pos2">Administrator</option> <option value="pos3">Management Staff</option> <option value="pos4">Cleaner</option> <option value="pos4">Equipment Maintenance</option> </select> </p>

    <br>

    <p>Additional Questions or Queries can be highlighted below</p>
    <input type="text" name="quiries" size="150" style="height: 300px;" />

    <p>Upload File(s)...</p>
    <img src="upload.png" alt="Upload CV" height="42" width="42" padx="20">

    <br>
    </label>
    <p>By uploading this documentation and applying for a position at MyMusicSchool, you agree to our Terms & Privacy Statement</a>.</p>

    <div class="clearfix">
      <button type="reset" class="cancelbtn">Cancel</button>
      <button type="submit" class="signupbtn">Apply</button>
    </div>
    </div>

    </form>
    </Center>

    
      
    """
        
    #Writing the Code to File
    Teacher_Application_Page.write(html_code)
    Teacher_Application_Page.close()
              
#Running the Definition
Teacher_Application_Page()
