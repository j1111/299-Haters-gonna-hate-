from urllib import urlopen
# Import the standard SQLite functions just in case they're needed.

#--------------------------------------------------------------------#

def Welcome_Page(): 

    file_name = 'Welcome_Page.html'

    Welcome_Page = open(file_name, 'w+')
    
    html_code = """

<style>
* {box-sizing: border-box;}

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  background-image: url("violin.jpg"); 
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}

.topnav input[type=text] {
  float: right;
  padding: 6px;
  margin-top: 8px;
  margin-right: 16px;
  border: none;
  font-size: 17px;
}

@media screen and (max-width: 600px) {
  .topnav a, .topnav input[type=text] {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
</style>
    <div class="topnav">
      <a class="active" href="#home">Home</a>
      <a href="About_Us_Page.html">About</a>
      <a href="Teacher_Application_Page.html">Teaching Application</a>
      <a href="Teacher_Application_Page.html">FAQ</a>
      <a href="Log in Page.html">Login</a>
      <input type="text" placeholder="Search..">
      
    </div>
     <center>


    <form action="action_page.php">
    <div class="container">
    <h1>Pinelands Music School</h1>

    </form>
    </center>
 
    """
    
    Welcome_Page.write(html_code)
    Welcome_Page.close()

def About_Us_Page(): 

    file_name = 'About_Us_Page.html'

    About_Us_Page = open(file_name, 'w+')
    
    html_code = """
<!DOCTYPE html>
<html>
  <head>
          <title>About_Us_Page</title>
          <script type="text/javascript" src="myscript.js"></script>
          <!-- <link href= "w5workshopstyle.css" rel="stylesheet" type="text/css"/>  -->
           </head>
<body>
                <style>
                * {box-sizing: border-box;}

                body {
                  margin: 0;
                  font-family: Arial, Helvetica, sans-serif;
                  background-image: url("violin.jpg"); 
                }

                .topnav {
                  overflow: hidden;
                  background-color: #fff;
                }

                .topnav a {
                  float: left;
                  display: block;
                  color: f2f2f2;
                  text-align: center;
                  padding: 14px 16px;
                  text-decoration: none;
                  font-size: 17px;
                }

                .topnav a:hover {
                  background-color: #ddd;
                  color: black;
                }

                .topnav a.active {
                  background-color: #4CAF50;
                  color: white;
                }

                .topnav input[type=text] {
                  float: right;
                  padding: 6px;
                  margin-top: 8px;
                  margin-right: 16px;
                  border: none;
                  font-size: 17px;
                }
                .aboutbox {
                  color: black;
                  width: 50%;
                  margin: auto;
                  text-align: center;
                  background-color: white;
                  opacity: 0.9;
                }


                @media screen and (max-width: 600px) {
                  .topnav a, .topnav input[type=text] {
                    float: none;
                    display: block;
                    text-align: left;
                    width: 100%;
                    margin: 0;
                    padding: 14px;
                  }
                  .topnav input[type=text] {
                    border: 1px solid #ccc;  
                  }
                  .writing {
                    text-align: center;
                  }
                }
                </style>
                    <div class="topnav">
                      <a class="active" href="Welcome_Page.html">Home</a>
                      <a href="About_Us_Page.html">About</a>
                      <a href="Teacher_Application_Page.html">Teaching Application</a>
                      <a href="Teacher_Application_Page.html">FAQ</a>
                      <a href="Log in Page.html">Login</a>
                      <input type="text" placeholder="Search..">
                      
                    </div>
                     <center>
                    <form action="action_page.php">
                    <div class="container">
                    <h1>About Us</h1>
                    </div>
                    </form>
                    </center>

              <div class="aboutbox" > 
                <h2 id = "Background"> Music School's Background</h2>
                <script type="text/javascript">
                  document.write("Brief overview of the Music School gives a quick insight of when the school was established, school’s achievements and future goals.");
                  console.log("Here is a log message");
                </script>

                <h2 id = "Teachers"> Our Teaching Team </h2>

                <ul id="teachers">
                <li>Mr Teacher</li>
                    <img src="mr_smith.jpg" alt="photo of Mr Teacher">
                  <ul>
                    <li>Speaks: Spanish, English</li>
                    <li>Teaches: Guitar, Piano</li>
                  </ul>
                <li>Ms Smith</li>
                    <img src="ms_smith.jpg" style="height:300px" alt="photo of Ms Smith">
                  <ul>
                    <li>Speaks: English</li>
                    <li>Teaches: Piano</li>
                  </ul>
                <li>Mrs Teacher</li>
                    <img src="ms_teacher.jpg" style="height:300px" alt="photo of Mrs Teacher">
                  <ul>
                    <li>Speaks: Spanish</li>
                    <li>Teaches: Xylophone</li>
                  </ul>
                </ul>

                <br>
                <div class="button" style="border:2px; background-color: #fff; height:20px; width: 300px">
                  <a href="Welcome_Page.html" class="button" style="color:black">Return to Home Page</a>
                </div>
                


                <p id="date"></p>
              </div>    
                <script type="text/javascript">
                  document.write(new Date().toDateString(); );
                </script>

</body>
</html>
 
    """
    
    About_Us_Page.write(html_code)
    About_Us_Page.close()

def Teacher_Application_Page(): 

    file_name = 'Teacher_Application_Page.html'

    Teacher_Application_Page = open(file_name, 'w+')
    
    html_code = """
<style>
                * {box-sizing: border-box;}

                body {
                  margin: 0;
                  font-family: Arial, Helvetica, sans-serif;
                  background-image: url("violin.jpg"); 
                }

                .topnav {
                  overflow: hidden;
                  background-color: #333;
                }

                .topnav a {
                  float: left;
                  display: block;
                  color: #ccc;
                  text-align: center;
                  padding: 14px 16px;
                  text-decoration: none;
                  font-size: 17px;
                }

                .topnav a:hover {
                  background-color: #ddd;
                  color: black;
                }

                .topnav a.active {
                  background-color: #4CAF50;
                  color: white;
                }

                .topnav input[type=text] {
                  float: right;
                  padding: 6px;
                  margin-top: 8px;
                  margin-right: 16px;
                  border: none;
                  font-size: 17px;
                }

                @media screen and (max-width: 600px) {
                  .topnav a, .topnav input[type=text] {
                    float: none;
                    display: block;
                    text-align: left;
                    width: 100%;
                    margin: 0;
                    padding: 14px;
                  }
                  .topnav input[type=text] {
                    border: 1px solid #ccc;  
                  }
                }

                .box {
                    background-color: #fff;
                    width: 50%;
                    opacity: 0.9;
                }
                </style>
                    <div class="topnav">
                      <a class="active" href="Welcome_Page.html">Home</a>
                      <a href="About_Us_Page.html">About</a>
                      <a href="Teacher_Application_Page.html">Teaching Application</a>
                      <a href="Teacher_Application_Page.html">FAQ</a>
                      <a href="Log in Page.html">Login</a>
                      <input type="text" placeholder="Search..">
                      
                    </div>
                     <center>
    <center>
    <body style="background-color: #fff">
        <Center>
    <div class="box">
        <form action="action_page.php">
    <div class="container">
    <h1>Apply for a Teaching Position</h1>
    <p>Please fill in this form to Apply for a Teaching Position.</p>
    <hr>
    
    <br>
    <label for="email"><b>Email</b></label>
    <br>
    <input type="text" placeholder="Enter Email" name="email" required>
    <br>
    
    <br>
    <label for="DOB"><b>Enter Date of Birth</b></label>
    <br>
    <input type="text" placeholder="dd/mm/yyyy" name="Date Of Birth" required>
    <br>

    <br>
    <label for="Phone No."><b>Enter Contact Number</b></label>
    <br>
    <input type="text" placeholder="00 0000 0000" name="Phone Number Required" required>
    <br>

    <p>Select Gender <select name="cars"> <option value="volvo">Male</option> <option value="saab">Female</option> <option value="fiat">Other</option> </select> </p>
    
    <p>Select Position <select name="positions"> <option value="pos1">Teacher</option> <option value="pos2">Administrator</option> <option value="pos3">Management Staff</option> <option value="pos4">Cleaner</option> <option value="pos4">Equipment Maintenance</option> </select> </p>

    <br>

    <p>Additional Questions or Queries can be highlighted below</p>
    <input type="text" name="quiries" size="150" style="height: 300px; width: 400px" />

    <p>Upload File(s)...</p>
    <img src="upload.png" alt="Upload CV" height="42" width="42" padx="20">

    <br>
    </label>
    <p>By uploading this documentation and applying for a position at MyMusicSchool, you agree to our Terms & Privacy Statement</a>.</p>

    <div class="clearfix">
      <a href="Welcome_Page.html" class="button">Cancel</a>
      <button type="submit" class="signupbtn">Apply</button>
    </div>
    </div>

    </form>
    </div>
    </Center>
    </body>
     
    """
    
    Teacher_Application_Page.write(html_code)
    Teacher_Application_Page.close()
    
def FAQ_page(): 

    file_name = 'FAQ_page.html'

    FAQ_page = open(file_name, 'w+')
    
    html_code = """
 <!DOCTYPE html>
<html>


<script>

function aFunction() {
	
	
	
}

</script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
		<style>
		body {
			background-image: url("violin.jpg");
			background-size: 100%;
			 margin: 0;
		  	font-family: Arial, Helvetica, sans-serif;
		}
		.something {
				text-align: center;

		}
		.fa {
			padding: 20px;
			font-size: 30px;
			width: 50px;
			text-align: center;
			text-decoration: none;
			}

			/* Set a specific color for facebook image */

			/* Facebook */
			.fa-facebook {
				background: #3B5998;
				color: white;
			}
		
		.button {
			
			background-color: #ff9900;
			border: none;
			color: white;
			padding: 15px 32px;
			text-align: center;
			text-decoration: none;
			display: inline-block;
			font-size: 16px;
			margin: 4px 2px;
			cursor: pointer;
			
			
		}
			.card {
			  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
			  max-width: 60%;
			  margin: auto;
			  text-align: left;
			  font-family: arial;
			  background-color:white;
			  border-radius: 5px; 
			  opacity: 0.9;
		}

		.home-btn {
			background-color: DodgerBlue;
			border: none;
			color: white;
			text-align: center;
			
			padding: px 20px;
			font-size: 30px;
			cursor: pointer;
		}
		
			.text {
			  color: white;
			  font-size: 20px;
		}

			button:hover, a:hover {
			  opacity: 0.7;
		}

		.topnav {
		  overflow: hidden;
		  background-color: #fff;
		}

		.topnav a {
		  float: left;
		  display: block;
		  color: f2f2f2;
		  text-align: center;
		  padding: 14px 16px;
		  text-decoration: none;
		  font-size: 17px;
		}

		.topnav a:hover {
		  background-color: #ddd;
		  color: black;
		}

		.topnav a.active {
		  background-color: #4CAF50;
		  color: white;
		}

		.topnav input[type=text] {
		  float: right;
		  padding: 6px;
		  margin-top: 8px;
		  margin-right: 16px;
		  border: none;
		  font-size: 17px;
		}

		</style>
	</head>
	<body>
	
	 <div class="topnav">
      <a class="active" href="#home">Home</a>
      <a href="About_Us_Page.html">About</a>
      <a href="Teacher_Application_Page.html">Teaching Application</a>
      <a href="Teacher_Application_Page.html">FAQ</a>
      <a href="Log in Page.html">Login</a>
      <input type="text" placeholder="Search..">
     </div>

     <h1 id="test" class="something">Frequently Asked Questions</h1>
	
	
	<a href="test.html"> <button type="button" onclick="aFunction()" id="btn6" <button class="home-btn"><i class="fa fa-home"></i></button></a>
	<a href="test.html"> <button type="button" onclick="aFunction()" id="btn7" class="fa fa-facebook"></button></a>
	
	
	<div class="card">
	  
	  <div style="margin: 24px 0;">
		 
		 
	<p class="text" style="color:red;">Q1. How long does it take to learn an instrument?</p>
	<p class="text" style="color:blue;">There is no set answer of how long it takes to learn an instrument. This varies from student <br>to student and really depends on the individual, how much practicing you do and your age. </p>
	<p class="text" style="color:red;">Q2. What instruments do you teach?</p>
	<p class="text" style="color:blue;">We offer Guitar, Piano/Keyboard, Male/Female Voice, Bass Guitar, Double Bass, Sax, Flute,<br> Clarinet, Violin, Cello, Trumpet and Drums.</p>
	<p class="text" style="color:red;">Q3. I've never played music before, can you help me?</p>
	<p class="text" style="color:blue;">Of course we can, everyone can play music, including you. Start today!</p>
	<p class="text" style="color:red;">Q4. What times are you open?</p>
	<p class="text" style="color:blue;">From 9am till 9pm, but available lesson times depend on our current volume.</p>
	<p class="text" style="color:red;">Q5. May I be present at my child's private music lesson?</p>
	<p class="text" style="color:blue;">Yes. In fact, we encourage parents to actively participate in child’s music education.</p>
	
		
	 
	 
		
	  </div>
	 
	</div>

	
	</body>
</html>
    """
    
    FAQ_page.write(html_code)
    FAQ_page.close()

def Log_In_Page(): 

    file_name = 'Log In Page.html'

    Log_In_Page = open(file_name, 'w+')
    
    html_code = """
 <!DOCTYPE html>
<html>


<script>

function aFunction() {
	
	
	
}

</script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
		<style>
		* {box-sizing: border-box;}
		body {
			background-image: url("violin.jpg");
			background-size: 100%;
			margin: 0;
  			font-family: Arial, Helvetica, sans-serif;
		}
		.something {
				text-align: center;

		}
		.fa {
			padding: 20px;
			font-size: 30px;
			width: 50px;
			text-align: center;
			text-decoration: none;
			}

			/* Set a specific color for facebook image */

			/* Facebook */
			.fa-facebook {
				background: #3B5998;
				color: white;
			}
		
		.button {
			
			background-color: #ff9900;
			border: none;
			color: white;
			padding: 15px 32px;
			text-align: center;
			text-decoration: none;
			display: inline-block;
			font-size: 16px;
			margin: 4px 2px;
			cursor: pointer;
			
			
		}
		.loginbtn  {
			width: 100%;
           padding: 10px 18px;
           background-color: #0099ff;				
		}
		
		.resetbtn {
           width: 100%;
           padding: 10px 18px;
           background-color: #f44336;
        }
		
		input[type=text], input[type=password] {
			width: 100%;
			padding: 12px 20px;
			margin: 8px 0;
			display: inline-block;
			border: 1px solid #ccc;
			box-sizing: border-box;
		}
		.card {
			 box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
			 max-width: 20%;
			 margin: auto;
			 text-align: left;
			 font-family: arial;
			 background-color:white;
			 border-radius: 5px; 
			 background-image: url("violin.jpg");
		}
		
		.container {
			padding: 16px;
		}

		.home-btn {
			background-color: DodgerBlue;
			border: none;
			color: white;
			text-align: center;
			
			padding: px 20px;
			font-size: 30px;
			cursor: pointer;
		}
		
		.text {
			  color: white;
			  font-size: 20px;
		}
		.topnav {
		  overflow: hidden;
		  background-color: #fff;
		}

		.topnav a {
		  float: left;
		  display: block;
		  color: f2f2f2;
		  text-align: center;
		  padding: 14px 16px;
		  text-decoration: none;
		  font-size: 17px;
		}

		.topnav a:hover {
		  background-color: #ddd;
		  color: black;
		}

		.topnav a.active {
		  background-color: #4CAF50;
		  color: white;
		}

		.topnav input[type=text] {
		  float: right;
		  padding: 6px;
		  margin-top: 8px;
		  margin-right: 16px;
		  border: none;
		  font-size: 17px;
		  width: 300px;
		}

		@media screen and (max-width: 600px) {
		  .topnav a, .topnav input[type=text] {
		    float: none;
		    display: block;
		    text-align: left;
		    width: 100%;
		    margin: 0;
		    padding: 14px;
		  }
		  .topnav input[type=text] {
		    border: 1px solid #ccc;  
		  }

		button:hover, a:hover {
			  opacity: 0.7;
		}
	}
		</style>
	</head>
	<body>
	<div class="topnav">
      <a class="active" href="#home">Home</a>
      <a href="About_Us_Page.html">About</a>
      <a href="Teacher_Application_Page.html">Teaching Application</a>
      <a href="Teacher_Application_Page.html">FAQ</a>
      <a href="Log in Page.html">Login</a>
      <input type="text" placeholder="Search..">
      
    </div>
     <center>


    <form action="action_page.php">
    <div class="container">
	<h1 id="test" class="something">Log In Page</h1>
	
	
	<a href="Welcome_Page.html"> <button type="button" onclick="aFunction()" id="btn6" <button class="home-btn"><i class="fa fa-home"></i></button></a>
	<a href="https://www.facebook.com"> <button type="button" onclick="aFunction()" id="btn7" class="fa fa-facebook"></button></a>
	
	
	<div class="card">
	  
	  <div style="margin: 24px 0;">
		 
		 
		<form action="/action_page.php">
		
			  <div class="imgcontainer">
				
			  </div>

					  <div class="container">
						<label for="uname"><b>Username</b></label>
						<input type="text" placeholder="Enter Username" name="uname" required>

						<label for="psw"><b>Password</b></label>
						<input type="password" placeholder="Enter Password" name="psw" required>
							
						<a href="Unique_User_Page.html"><button type="submit" style="width:100%" class="loginbtn">Login</button></a>
						<label>
						  <input type="checkbox" checked="checked" name="remember"> Remember me
						</label>
						
						<input type="reset" class="resetbtn" value="Reset">
						
					  </div>

		</form>
		
	 
	
		
	  </div>
	 
	</div>

	
	</body>
</html> 
    """
    
    Log_In_Page.write(html_code)
    Log_In_Page.close()

def Create_Account_Page(): 

    file_name = 'Create_Account_Page.html'

    Create_Account_Page = open(file_name, 'w+')
    
    html_code = """
<!DOCTYPE html>
<html>
<body>
<style>
div.a {
text-align: center;'
}
div.b {
text-align: center/2;
}                              
body, html {
height: 100%;
margin: 0;
background-image: url("1.png");
height: 100%;
background-position: center;
background-repeat: no-repeat;
background-size: cover;
}
</style>
<div class="a">                               
<h><font size = "30"> Create your account </font></h>
<form action="/action_page.php">
<br><br><br><br><br><br><br><br>
First Name:
&emsp;&emsp;&emsp;&emsp;Email:
<br>                             
<input type="text" name="firstname" value="Ex:John">
&emsp;&emsp;&emsp;&emsp;<input type="text" name="email"value="your email address">
<br>
<br>                              
Last Name:
&emsp;&emsp;&emsp;&emsp; Password:
<br>
<input type="text" name="lastname" value="Ex:Smith">
&emsp;&emsp;&emsp;&emsp;<input type="text" name="password"value="9-16 characters">
<br>
<br>                              
Gender:
<br>
<form>
<input type="radio" name="gender" value="male"> Male<br>
<input type="radio" name="gender" value="female"> Female<br>
<input type="radio" name="gender" value="other"> Other
</form> 
<br>
<br>                             
&emsp;&emsp;&emsp;&emsp;DOB:
&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Confirm Password:
<br>
<input type="text" name="dayofbirth" value="DD/MM/YY">
&emsp;&emsp;&emsp;<input type="text" name="confirmpassword"value="Re-enter your password">
<br>
<br>
<br>                              
Contact Number:
<br>
&emsp;&emsp;&emsp;&emsp;<input type="text" name="phonenumber" value="Ex:0123456789">                        
<br><br>
<br><br>
<input type="submit" value="Submit">
&emsp;&emsp;&emsp;&emsp;<input type="submit" value="Cancel">
</form>
</div>                            
</body>
</html>
 
    """
    
    Create_Account_Page.write(html_code)
    Create_Account_Page.close()

def Unique_User_Page(): 

    file_name = 'Unique_User_Page.html'

    Unique_User_Page = open(file_name, 'w+')
    
    html_code = """

html paste
<!DOCTYPE html>
<html>


<script>

function aFunction() {
	
	
	
}

</script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
		<style>
		body {
			background-image: url("violin.jpg");
			background-size: 100%;
		}
		.something {
				text-align: center;

		}
		.fa {
			padding: 20px;
			font-size: 30px;
			width: 50px;
			text-align: center;
			text-decoration: none;
			}

			/* Set a specific color for facebook image */

			/* Facebook */
			.fa-facebook {
				background: #3B5998;
				color: white;
			}
		
		.button {
			
			background-color: #ff9900;
			border: none;
			color: white;
			padding: 15px 32px;
			text-align: center;
			text-decoration: none;
			display: inline-block;
			font-size: 16px;
			margin: 4px 2px;
			cursor: pointer;
			
			
		}

		.home-btn {
			background-color: DodgerBlue;
			border: none;
			color: white;
			text-align: center;
			
			padding: px 20px;
			font-size: 30px;
			cursor: pointer;
		}
		input[type=text], select {
			width: 60%;
			padding: 12px 20px;
			margin: 8px 0;
			display: inline-block;
			border: 1px solid #ccc;
			border-radius: 4px;
			box-sizing: border-box;
			
		}
		.card {
			  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
			  max-width: 300px;
			  margin: auto;
			  text-align: center;
			  font-family: arial;
			  background-color:white;
		}

			.title {
			  color: grey;
			  font-size: 18px;
		}

			buttonC {
			  border: none;
			  outline: 0;
			  display: inline-block;
			  padding: 8px;
			  color: white;
			  background-color: #000;
			  text-align: center;
			  cursor: pointer;
			  width: auto;
			  font-size: 18px;
			 
		}

			a {
			  text-decoration: none;
			  font-size: 22px;
			  color: black;
		}

			button:hover, a:hover {
			  opacity: 0.7;
		}
		</style>
	</head>
	<body>
	
<style>
                * {box-sizing: border-box;}

                body {
                  margin: 0;
                  font-family: Arial, Helvetica, sans-serif;
                }

                .topnav {
                  overflow: hidden;
                  background-color: #333;
                }

                .topnav a {
                  float: left;
                  display: block;
                  color: #ccc;
                  text-align: center;
                  padding: 14px 16px;
                  text-decoration: none;
                  font-size: 17px;
                }

                .topnav a:hover {
                  background-color: #ddd;
                  color: black;
                }
                .topnav a.active {
                  background-color: #4CAF50;
                  color: white;
                }

                .topnav input[type=text] {
                  float: right;
                  padding: 6px;
                  margin-top: 8px;
                  margin-right: 16px;
                  border: none;
                  font-size: 17px;
                }

                @media screen and (max-width: 600px) {
                  .topnav a, .topnav input[type=text] {
                    float: none;
                    display: block;
                    text-align: left;
                    width: 100%;
                    margin: 0;
                    padding: 14px;
                  }
                  .topnav input[type=text] {
                    border: 1px solid #ccc;  
                  }
                }
                </style>
                    <div class="topnav">
                      <a class="active" href="Welcome_Page.html">Home</a>
                      <a href="About_Us_Page.html">About</a>
                      <a href="Teacher_Application_Page.html">Teaching Application</a>
                      <a href="Teacher_Application_Page.html">FAQ</a>
                      <a href="Log in Page.html">Login</a>
                      <input type="text" placeholder="Search..">
                      
                    </div>
                     <center>
    <center>
	
	
	
	
	<div class="card">
	  <img src="student.jpg" alt="Jessica" style="width:100%">
	  <h1>Jessica Smith</h1>
	  <p class="title">Student</p>
	  <p>Music School</p>
	  <div style="margin: 24px 0;">
		 
		<input type="text" placeholder="Name" name="Name" required value="Jessica">
		<input type="text" placeholder="Surname" name="Surname" required value="Smith">
		<input type="text" placeholder="Email" name="email" required value="j.smith@gmail.com">
		<input type="text" placeholder="DOB" name="DOB" required value="01.01.1990">
		<input type="text" placeholder="Address" name="Address" required value="10 Park Street Gabba">
		<input type="text" placeholder="Phone Number" name="Phone Number" required value="3358-2397">
	 
		
	 </div>
	 <a href="test.html"> <button type="button" onclick="aFunction()" id="btn8" class="button">UPDATE</button></a>
	</div>
	
	</body>
</html>
    """
    
    Unique_User_Page.write(html_code)
    Unique_User_Page.close() 
#Running the main
Welcome_Page()


