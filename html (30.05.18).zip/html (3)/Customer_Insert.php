<?php
    session_start();

    $email = "";
    $errors = array();
    $db = new mysqli('localhost', 'root','','customer');
    

    if(isset($_POST['sign_up'])){
    	$username = mysqli_real_escape_string($db, $_POST['username']);
    	$firstname = mysqli_real_escape_string($db, $_POST['firstname']);
    	$lastname = mysqli_real_escape_string($db, $_POST['lastname']);
    	$email = mysqli_real_escape_string($db , $_POST['email']);
    	$DOB = mysqli_real_escape_string($db, $_POST['DOB']);
    	$phoneno = mysqli_real_escape_string($db , $_POST['phoneno']);
    	$Gender = mysqli_real_escape_string($db, $_POST['Gender']);
    	$password = mysqli_real_escape_string($db, $_POST['password']);
    	$confirmpassword = mysqli_real_escape_string( $db,$_POST['confirmpassword']);

	    
		
		
    	if(count($errors)==0){
            
    		$query = "INSERT INTO account (username,firstname,lastname,email,DOB,phoneno,Gender,password) VALUES('$username','$firstname','$lastname','$email', '$DOB','$phoneno','$Gender','$password')";
    		mysqli_query($db, $query);
    		
    		header('location: Create_Success.html');
    	}
    }



    ?>