<?php
    session_start();

    $email = "";
    $errors = array();
    $db = new mysqli('localhost', 'root','','customer');
    

    if(isset($_POST['booklesson'])){
    	$startdate = mysqli_real_escape_string($db, $_POST['startdate']);
    	$enddate = mysqli_real_escape_string($db, $_POST['enddate']);
    	$instrument = mysqli_real_escape_string($db, $_POST['instrument']);
    	$duration = mysqli_real_escape_string($db , $_POST['duration']);
    	$lessoncost = mysqli_real_escape_string($db, $_POST['lessoncost']);
    	$additional= mysqli_real_escape_string($db , $_POST['additional']);
    	
    	

	    
		
		
    	if(count($errors)==0){
            
    		$query = "INSERT INTO booklesson (startdate,enddate,instrument,duration,lessoncost,additional) VALUES('$startdate ','$enddate','$instrument','$duration', '$lessoncost','$additional')";
    		mysqli_query($db, $query);
    		
    		header('location: Book Success.html');
    	}
    }



    ?>