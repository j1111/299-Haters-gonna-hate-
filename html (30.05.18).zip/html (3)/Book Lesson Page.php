<?php include('book_insert.php'); ?>
<style>
                * {box-sizing: border-box;}

                body {
                  margin: 0;
                  font-family: Arial, Helvetica, sans-serif;
                  background-image: url("violin.jpg"); 
                }

                .topnav {
                  overflow: hidden;
                  background-color: #333;
                }

                .topnav a {
                  float: left;
                  display: block;
                  color: #ccc;
                  text-align: center;
                  padding: 14px 16px;
                  text-decoration: none;
                  font-size: 17px;
                }

                .topnav a:hover {
                  background-color: #ddd;
                  color: black;
                }

                .topnav a.active {
                  background-color: #4CAF50;
                  color: white;
                }

                .topnav input[type=text] {
                  float: right;
                  padding: 6px;
                  margin-top: 8px;
                  margin-right: 16px;
                  border: none;
                  font-size: 17px;
                }

                @media screen and (max-width: 600px) {
                  .topnav a, .topnav input[type=text] {
                    float: none;
                    display: block;
                    text-align: left;
                    width: 100%;
                    margin: 0;
                    padding: 14px;
                  }
                  .topnav input[type=text] {
                    border: 1px solid #ccc;  
                  }
                }
               
                .box {
                    background-color: #fff;
                    width: 50%;
                    opacity: 0.9;
                }
                </style>
                   
                   
                     <center>
    <center>
    <body style="background-color: #fff">
        <Center>
    <div class="box">
        
    <div class="container">
    <h1>Book your Lesson</h1>
    <hr>
    <form method = "POST" action="book_insert.php" >
    
    <br>
    <label for="startday"><b>Start Day</b></label>
    <br>
    <input type="text" placeholder="dd/mm/yy" name="startdate" required>
    <br>
    <label for="enddate"><b>End Date</b></label>
    <br>
    <input type="text" placeholder="dd/mm/yy" name="enddate" required>
    <br>
    <label for="instrument"><b>Instrument</b></label>
    <br>
    <input type="text" placeholder="Instrument used" name="instrument" required>
    <br>
    <label for="duration"><b>Duration</b></label>
    <br>
    <input type="text" placeholder="duration of a lesson" name="duration" required>
    <br>
    <label for="lessoncost"><b>Lesson Cost</b></label>
    <br>
    <input type="text" placeholder="Your fee" name="lessoncost" required>
    <br>
    <label for="add"><b>Additional comment</b></label>
    <br>
    <input type="text" name="additional" size="150" style="height: 300px; width: 400px" />
    
 
    </label>
    
    <div class="clearfix">
      <a href="Unique_User_Page.html" class="button">back</a>
       <button type="submit" class="btn" name= "booklesson">Apply</button) 
    </div>
    </div>


    </form>
    </div>
    </Center>
    </body>
    

    
      
    