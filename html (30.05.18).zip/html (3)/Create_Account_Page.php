
<?php include('Customer_Insert.php'); ?>

<!DOCTYPE html>
<html>
<style>


                * {box-sizing: border-box;}

                body {
                  margin: 0;
                  font-family: Arial, sans-serif;
                  background-image: url("violin.jpg"); 
                }

                .topnav {
                  overflow: hidden;
                  background-color: #333;
                }

                .topnav a {
                  float: left;
                  display: block;
                  color: #ccc;
                  text-align: center;
                  padding: 14px 16px;
                  text-decoration: none;
                  font-size: 17px;
                }

                .topnav a:hover {
                  background-color: #ddd;
                  color: black;
                }

                .topnav a.active {
                  background-color: #4CAF50;
                  color: white;
                }

                .topnav input[type=text] {
                  float: right;
                  padding: 6px;
                  margin-top: 8px;
                  margin-right: 16px;
                  border: none;
                  font-size: 17px;
                }

                @media screen and (max-width: 600px) {
                  .topnav a, .topnav input[type=text] {
                    float: none;
                    display: block;
                    text-align: left;
                    width: 100%;
                    margin: 0;
                    padding: 14px;
                  }
                  .topnav input[type=text] {
                    border: 1px solid #ccc;  
                  }
                }
               
                .box {
                    background-color: #fff;
                    width: 50%;
                    opacity: 0.9;
                }
                </style>
                    <div class="topnav">
                      <a class="active" href="Welcome_Page.html">Home</a>
                      <a href="About_Us_Page.html">About</a>
                      <a href="Teacher_Application_Page.html">Teaching Application</a>
                      <a href="FAQ_page.html">FAQ</a>
                      <a href="Log in Page.php">Login</a>
                      <input type="text" placeholder="Search..">
                      
                    </div>
                     <center>
    <center>
    <body style="background-color: #fff">
        <Center>
    <div class="box">
   
    <div class="container">
    <h1>Create your account</h1>
    <hr>
     <form method = "POST" action="Customer_Insert.php" >
     
    <br>
    <label for="username"><b>Username</b></label>
    <br>
    <input type="text" name="username" required >
    <br>
    <label for="firstname"><b>First Name</b></label>
    <br>
    <input type="text" placeholder="ex: John" name="firstname" required>
    <br>
    <label for="lastname"><b>Last Name</b></label>
    <br>
    <input type="text" placeholder="ex: Smith" name="lastname" required>
    <br>
    <label for="email"><b>Email</b></label>
    <br>
    <input type="text" placeholder="Enter Email" name="email" value ="<?php echo $email; ?>" required>
    <br>
    <label for="DOB"><b>Date of Birth</b></label>
    <br>
    <input type="text" placeholder="dd/mm/yyyy" name="DOB" required>
    <br>
    <label for="contactnum"><b>Contact Number</b></label>
    <br>
    <input type="int" placeholder="00 0000 0000" name="phoneno" required>
    <br>
    <p>Select Gender <select name="Gender"> <option value="Male">Male</option> <option value="Female">Female</option>     <option value="Other">Other</option> </select> </p>
    <label for="password"><b>Password</b></label>
    <br>
    <input type="text" placeholder="9-16 characters" name="password" required>
    <br>
    <label for="confirmpassword"><b>Confirm Password</b></label>
    <br>
    <input type="text" placeholder="re-enter your password" name="confirmpassword" required>
    
 
    </label>
    
    <div class="clearfix">
      <a href="Welcome_Page.html" class="button">back</a>
      <button type="submit" class="btn" name= "sign_up">Sign up</button)
      
    </div>
    </div>


    </form>
    </div>
    </Center>
    </body>
</html>

    

    
      
    