<?php include('log_in_insert.php'); ?>
<!DOCTYPE html>
<html>


<script>

function aFunction() {
	
	
	
}

</script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
		<style>
		* {box-sizing: border-box;}
		body {
			background-image: url("violin.jpg");
			background-size: 100%;
		}
		.something {
				text-align: center;

		}
		.fa {
			padding: 20px;
			font-size: 30px;
			width: 50px;
			text-align: center;
			text-decoration: none;
			}

			/* Set a specific color for facebook image */

			/* Facebook */
			.fa-facebook {
				background: #3B5998;
				color: white;
			}
		
		.button {
			
			background-color: #0099ff;
			
			color: white;
			padding: 10px 18px;
			text-align: center;
			text-decoration: none;
			display: inline-block;
			font-size: 16px;
			border: 1px solid #ccc;
			cursor: pointer;
			width: 100%;
			margin: 8px 0;
			
		}
		
		.resetbtn {
           width: 100%;
           padding: 10px 18px;
           background-color: #f44336;
        }
		
		input[type=text], input[type=password] {
			width: 100%;
			padding: 12px 20px;
			margin: 8px 0;
			display: inline-block;
			border: 1px solid #ccc;
			box-sizing: border-box;
		}
		.card {
			 box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
			 max-width: 20%;
			 margin: auto;
			 text-align: left;
			 font-family: arial;
			 background-color:white;
			 border-radius: 5px; 
			 background-image: url("violin.jpg");
		}
		
		.container {
			padding: 16px;
		}

		.home-btn {
			background-color: DodgerBlue;
			border: none;
			color: white;
			text-align: center;
			
			padding: px 20px;
			font-size: 30px;
			cursor: pointer;
		}
		
		.text {
			  color: white;
			  font-size: 20px;
		}

		button:hover, a:hover {
			  opacity: 0.7;
		}
		</style>
	</head>
	<body>




    <div class="container">
	<h1 id="test" class="something">Log In Page</h1>
	
	
	<a href="Welcome_Page.html"> <button type="button" onclick="aFunction()" id="btn6" <button class="home-btn"><i class="fa fa-home"></i></button></a>
	<a href="test.html"> <button type="button" onclick="aFunction()" id="btn7" class="fa fa-facebook"></button></a>
	
	
	<div class="card">
	  
	  <div style="margin: 24px 0;">
		 
		 
			<form method = "POST" action="log_in_insert.php" >
		
			  <div class="imgcontainer">
				
			  </div>

					  <div class="container">
						<label for="uname"><b>Username</b></label>
						<input type="text" placeholder="Enter Username" name="username" required>

						<label for="psw"><b>Password</b></label>
						<input type="password" placeholder="Enter Password" name="password" required>
						
						<label>
						  <input type="checkbox" checked="checked" name="remember"> Remember me
						</label>
						<input type="reset" class="resetbtn" value="Reset">		
						<button type="submit" class="button" name= "login_user">Log in</button)		
									

						
						
						
					  </div>

			</form>
		
	 
</form>	
		
	  </div>
	 
	</div>

	
	</body>
</html>